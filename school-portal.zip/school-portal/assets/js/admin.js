/* =========================================================
   admin.js — admin dashboard behaviour
   ========================================================= */

(function () {
  const session = Auth.requireRole('admin');
  if (!session) return; // requireRole already redirected

  document.getElementById('admin-name').textContent = session.name;

  /* ---------------- Navigation ---------------- */
  const titles = {
    overview: ['Overview', 'A quick look at fees, notes and announcements'],
    fees: ['Fee ledger', 'Track payments across every student'],
    notes: ['Class notes & resources', 'Shared study material by subject and grade'],
    announcements: ['Announcements & updates', 'School-wide notices, pinned to the top'],
    students: ['Students', 'Manage student records and parent/guardian accounts']
  };

  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
      const target = item.dataset.section;
      document.querySelectorAll('.nav-item').forEach(n => { n.classList.remove('active'); n.removeAttribute('aria-current'); });
      item.classList.add('active');
      item.setAttribute('aria-current', 'page');
      document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
      document.getElementById('section-' + target).classList.add('active');
      document.getElementById('page-title').textContent = titles[target][0];
      document.getElementById('page-sub').textContent = titles[target][1];
      document.getElementById('sidebar').classList.remove('open');
    });
  });

  document.getElementById('menu-btn').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
  });

  document.getElementById('logout-btn').addEventListener('click', Auth.logout);

  document.getElementById('reset-data-btn').addEventListener('click', () => {
    if (confirm('Reset all demo data? This clears every change you have made in this browser.')) {
      DB.resetAll();
      renderAll();
      toast('Demo data has been reset.');
    }
  });

  /* ---------------- Modal helpers ---------------- */
  const backdrop = document.getElementById('modal-backdrop');
  const modalBody = document.getElementById('modal-body');

  function openModal(html) {
    modalBody.innerHTML = html;
    backdrop.classList.add('open');
    const firstInput = modalBody.querySelector('input, select, textarea');
    if (firstInput) firstInput.focus();
  }
  function closeModal() {
    backdrop.classList.remove('open');
    modalBody.innerHTML = '';
  }
  backdrop.addEventListener('click', (e) => { if (e.target === backdrop) closeModal(); });
  document.addEventListener('keydown', (e) => { if (e.key === 'Escape') closeModal(); });

  /* ---------------- Helpers ---------------- */
  function studentName(id) {
    const s = DB.getStudent(id);
    return s ? s.name : 'Unknown student';
  }
  function studentGrade(id) {
    const s = DB.getStudent(id);
    return s ? s.grade : '—';
  }
  function parentLabel(user) {
    return `${user.name} (@${user.username})`;
  }

  /* ================================================================
     OVERVIEW
     ================================================================ */
  function renderOverview() {
    const fees = DB.getFees();
    const students = DB.getStudents();
    const outstanding = fees.reduce((sum, f) => {
      const remaining = Math.max(0, Number(f.amountDue) - Number(f.amountPaid));
      return sum + remaining;
    }, 0);
    const overdue = fees.filter(f => feeStatus(f) === 'overdue');
    const paidCount = fees.filter(f => feeStatus(f) === 'paid').length;

    document.getElementById('stat-grid').innerHTML = `
      <div class="stat-tile"><div class="num">${students.length}</div><div class="label">Students</div></div>
      <div class="stat-tile ${overdue.length ? 'alert' : ''}"><div class="num">${overdue.length}</div><div class="label">Overdue accounts</div></div>
      <div class="stat-tile"><div class="num mono">${formatCurrency(outstanding)}</div><div class="label">Outstanding</div></div>
      <div class="stat-tile"><div class="num">${paidCount}</div><div class="label">Fully paid</div></div>
    `;

    const tbody = document.querySelector('#overview-overdue-table tbody');
    if (overdue.length === 0) {
      tbody.innerHTML = `<tr class="empty-row"><td colspan="6">No overdue fees right now.</td></tr>`;
    } else {
      tbody.innerHTML = overdue.slice(0, 6).map(f => `
        <tr>
          <td>${escapeHTML(studentName(f.studentId))}</td>
          <td>${escapeHTML(studentGrade(f.studentId))}</td>
          <td>${escapeHTML(f.description)}</td>
          <td>${formatDate(f.dueDate)}</td>
          <td class="amount">${formatCurrency(Number(f.amountDue) - Number(f.amountPaid))}</td>
          <td><span class="stamp overdue">Overdue</span></td>
        </tr>
      `).join('');
    }

    const annHost = document.getElementById('overview-announcements');
    const latest = DB.getAnnouncements().slice(0, 3);
    annHost.innerHTML = latest.length ? latest.map(renderAnnouncementEntry).join('') : `<p style="color:var(--slate); font-size:13.5px;">No announcements yet.</p>`;
  }

  /* ================================================================
     FEES
     ================================================================ */
  function getFeeFilterState() {
    return {
      q: document.getElementById('fee-search').value.trim().toLowerCase(),
      status: document.getElementById('fee-filter').value
    };
  }

  function renderFees() {
    const { q, status } = getFeeFilterState();
    let fees = DB.getFees();
    fees = fees.filter(f => {
      const matchesQ = !q || studentName(f.studentId).toLowerCase().includes(q);
      const matchesStatus = status === 'all' || feeStatus(f) === status;
      return matchesQ && matchesStatus;
    });

    const tbody = document.querySelector('#fees-table tbody');
    if (fees.length === 0) {
      tbody.innerHTML = `<tr class="empty-row"><td colspan="9">No fee records match.</td></tr>`;
      return;
    }
    tbody.innerHTML = fees.map(f => {
      const status = feeStatus(f);
      return `
      <tr data-fee-row="${f.id}">
        <td>${escapeHTML(studentName(f.studentId))}</td>
        <td>${escapeHTML(studentGrade(f.studentId))}</td>
        <td>${escapeHTML(f.term)} ${escapeHTML(String(f.year))}</td>
        <td>${escapeHTML(f.description)}</td>
        <td class="amount">${formatCurrency(f.amountDue)}</td>
        <td class="amount">${formatCurrency(f.amountPaid)}</td>
        <td>${formatDate(f.dueDate)}</td>
        <td><span class="stamp ${status}">${STATUS_LABEL[status]}</span></td>
        <td class="row-actions">
          <button class="btn small secondary" data-action="pay" data-id="${f.id}" ${status === 'paid' ? 'disabled' : ''}>Record payment</button>
          <button class="btn small secondary" data-action="edit-fee" data-id="${f.id}">Edit</button>
          <button class="btn small danger" data-action="delete-fee" data-id="${f.id}">Delete</button>
        </td>
      </tr>`;
    }).join('');
  }

  document.getElementById('fee-search').addEventListener('input', debounce(renderFees, 150));
  document.getElementById('fee-filter').addEventListener('change', renderFees);

  function feeFormModal(existing) {
    const students = DB.getStudents();
    const isEdit = !!existing;
    const studentOptions = students.map(s =>
      `<option value="${s.id}" ${existing && existing.studentId === s.id ? 'selected' : ''}>${escapeHTML(s.name)} — ${escapeHTML(s.grade)}</option>`
    ).join('');

    openModal(`
      <h2>${isEdit ? 'Edit fee record' : 'Add fee record'}</h2>
      <form id="fee-form">
        <div class="field">
          <label for="f-student">Student</label>
          <select id="f-student" required>${studentOptions}</select>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="f-term">Term</label>
            <select id="f-term">
              ${['Term 1', 'Term 2', 'Term 3', 'Term 4'].map(t => `<option ${existing && existing.term === t ? 'selected' : ''}>${t}</option>`).join('')}
            </select>
          </div>
          <div class="field">
            <label for="f-year">Year</label>
            <input type="number" id="f-year" value="${escapeHTML(existing ? existing.year : new Date().getFullYear())}" min="2020" max="2100" required>
          </div>
        </div>
        <div class="field">
          <label for="f-desc">Description</label>
          <input type="text" id="f-desc" maxlength="120" value="${escapeHTML(existing ? existing.description : '')}" placeholder="e.g. Tuition fees" required>
        </div>
        <div class="field-row">
          <div class="field">
            <label for="f-amount">Amount due (R)</label>
            <input type="number" id="f-amount" min="0" step="0.01" value="${escapeHTML(existing ? existing.amountDue : '')}" required>
          </div>
          <div class="field">
            <label for="f-due">Due date</label>
            <input type="date" id="f-due" value="${escapeHTML(existing ? existing.dueDate : '')}" required>
          </div>
        </div>
        <div class="field-error" id="fee-form-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn secondary" data-action="close-modal">Cancel</button>
          <button type="submit" class="btn">${isEdit ? 'Save changes' : 'Add record'}</button>
        </div>
      </form>
    `);

    document.getElementById('fee-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const studentId = document.getElementById('f-student').value;
      const term = document.getElementById('f-term').value;
      const year = document.getElementById('f-year').value;
      const description = document.getElementById('f-desc').value.trim();
      const amountDue = document.getElementById('f-amount').value;
      const dueDate = document.getElementById('f-due').value;

      const err = validate.required(studentId, 'Student') || validate.required(description, 'Description') ||
        validate.maxLength(description, 120, 'Description') || validate.positiveNumber(amountDue, 'Amount due') ||
        validate.required(dueDate, 'Due date') || validate.positiveNumber(year, 'Year');
      if (err) { document.getElementById('fee-form-error').textContent = err; return; }

      if (isEdit) {
        DB.updateFee(existing.id, { studentId, term, year: Number(year), description, amountDue: Number(amountDue), dueDate });
        toast('Fee record updated.');
      } else {
        DB.addFee({ id: makeId('fee'), studentId, term, year: Number(year), description, amountDue: Number(amountDue), amountPaid: 0, dueDate, history: [] });
        toast('Fee record added.');
      }
      closeModal();
      renderFees();
      renderOverview();
    });
  }

  function paymentFormModal(fee) {
    const remaining = Math.max(0, Number(fee.amountDue) - Number(fee.amountPaid));
    openModal(`
      <h2>Record payment — ${escapeHTML(studentName(fee.studentId))}</h2>
      <p style="font-size:13px;color:var(--slate);margin-top:-8px;">Outstanding balance: <strong class="mono">${formatCurrency(remaining)}</strong></p>
      <form id="pay-form">
        <div class="field">
          <label for="p-amount">Amount received (R)</label>
          <input type="number" id="p-amount" min="0.01" step="0.01" max="${remaining}" value="${remaining}" required>
        </div>
        <div class="field">
          <label for="p-method">Method</label>
          <select id="p-method">
            <option>EFT</option><option>Card</option><option>Cash</option><option>Other</option>
          </select>
        </div>
        <div class="field">
          <label for="p-note">Note (optional)</label>
          <input type="text" id="p-note" maxlength="120">
        </div>
        <div class="field-error" id="pay-form-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn secondary" data-action="close-modal">Cancel</button>
          <button type="submit" class="btn">Record payment</button>
        </div>
      </form>
    `);

    document.getElementById('pay-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const amount = document.getElementById('p-amount').value;
      const method = document.getElementById('p-method').value;
      const note = document.getElementById('p-note').value.trim();
      const err = validate.positiveNumber(amount, 'Amount');
      if (err) { document.getElementById('pay-form-error').textContent = err; return; }
      if (Number(amount) > remaining + 0.0001) {
        document.getElementById('pay-form-error').textContent = `Amount can't exceed the outstanding balance of ${formatCurrency(remaining)}.`;
        return;
      }
      DB.recordPayment(fee.id, Number(amount), method, note);
      closeModal();
      renderFees();
      renderOverview();
      toast('Payment recorded.');
      requestAnimationFrame(() => {
        const row = document.querySelector(`[data-fee-row="${fee.id}"] .stamp`);
        if (row) { row.classList.add('pop'); setTimeout(() => row.classList.remove('pop'), 350); }
      });
    });
  }

  /* ================================================================
     NOTES
     ================================================================ */
  function renderNoteEntry(n) {
    return `
      <div class="entry">
        <div class="entry-top">
          <div>
            <h3>${escapeHTML(n.title)}</h3>
            <div class="meta">${escapeHTML(n.subject)} · ${escapeHTML(n.grade)} · posted by ${escapeHTML(n.postedBy)} · ${formatDate(n.datePosted)}</div>
          </div>
          <button class="btn small danger" data-action="delete-note" data-id="${n.id}">Delete</button>
        </div>
        <div class="body-text">${escapeHTML(n.content)}</div>
      </div>`;
  }

  function renderNotes() {
    const q = document.getElementById('notes-search').value.trim().toLowerCase();
    let notes = DB.getNotes();
    if (q) notes = notes.filter(n => [n.title, n.subject, n.grade].some(field => field.toLowerCase().includes(q)));
    document.getElementById('notes-list').innerHTML = notes.length
      ? notes.map(renderNoteEntry).join('')
      : `<p style="color:var(--slate); font-size:13.5px;">No notes match your search.</p>`;
  }
  document.getElementById('notes-search').addEventListener('input', debounce(renderNotes, 150));

  function noteFormModal() {
    openModal(`
      <h2>Add note</h2>
      <form id="note-form">
        <div class="field-row">
          <div class="field"><label for="n-subject">Subject</label><input type="text" id="n-subject" maxlength="60" required></div>
          <div class="field"><label for="n-grade">Grade</label><input type="text" id="n-grade" maxlength="30" placeholder="e.g. Grade 8" required></div>
        </div>
        <div class="field"><label for="n-title">Title</label><input type="text" id="n-title" maxlength="100" required></div>
        <div class="field"><label for="n-content">Content</label><textarea id="n-content" maxlength="2000" required></textarea></div>
        <div class="field-error" id="note-form-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn secondary" data-action="close-modal">Cancel</button>
          <button type="submit" class="btn">Add note</button>
        </div>
      </form>
    `);
    document.getElementById('note-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const subject = document.getElementById('n-subject').value.trim();
      const grade = document.getElementById('n-grade').value.trim();
      const title = document.getElementById('n-title').value.trim();
      const content = document.getElementById('n-content').value.trim();
      const err = validate.required(subject, 'Subject') || validate.required(grade, 'Grade') ||
        validate.required(title, 'Title') || validate.required(content, 'Content') ||
        validate.maxLength(content, 2000, 'Content');
      if (err) { document.getElementById('note-form-error').textContent = err; return; }
      DB.addNote({ id: makeId('note'), subject, grade, title, content, postedBy: session.name, datePosted: todayISO() });
      closeModal();
      renderNotes();
      toast('Note posted.');
    });
  }

  /* ================================================================
     ANNOUNCEMENTS
     ================================================================ */
  function renderAnnouncementEntry(a) {
    const tagClass = a.category === 'urgent' ? 'urgent' : a.category === 'event' ? 'event' : '';
    return `
      <div class="entry ${a.pinned ? 'pinned' : ''}">
        <div class="entry-top">
          <div>
            <h3>${escapeHTML(a.title)}</h3>
            <div class="meta">
              <span class="tag ${tagClass}">${escapeHTML(a.category)}</span>
              ${a.pinned ? '<span class="tag pinned">Pinned</span>' : ''}
              · ${escapeHTML(a.postedBy)} · ${formatDateTime(a.datePosted)}
            </div>
          </div>
        </div>
        <div class="body-text">${escapeHTML(a.body)}</div>
        <div class="row-actions">
          <button class="btn small secondary" data-action="toggle-pin" data-id="${a.id}">${a.pinned ? 'Unpin' : 'Pin'}</button>
          <button class="btn small danger" data-action="delete-announcement" data-id="${a.id}">Delete</button>
        </div>
      </div>`;
  }

  function renderAnnouncements() {
    const list = DB.getAnnouncements();
    document.getElementById('announcements-list').innerHTML = list.length
      ? list.map(renderAnnouncementEntry).join('')
      : `<p style="color:var(--slate); font-size:13.5px;">No announcements yet.</p>`;
  }

  function announcementFormModal() {
    openModal(`
      <h2>New announcement</h2>
      <form id="ann-form">
        <div class="field"><label for="a-title">Title</label><input type="text" id="a-title" maxlength="120" required></div>
        <div class="field"><label for="a-body">Message</label><textarea id="a-body" maxlength="2000" required></textarea></div>
        <div class="field-row">
          <div class="field">
            <label for="a-category">Category</label>
            <select id="a-category"><option value="general">General</option><option value="event">Event</option><option value="urgent">Urgent</option></select>
          </div>
          <div class="field">
            <label for="a-pinned">Pin to top</label>
            <select id="a-pinned"><option value="no">No</option><option value="yes">Yes</option></select>
          </div>
        </div>
        <div class="field-error" id="ann-form-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn secondary" data-action="close-modal">Cancel</button>
          <button type="submit" class="btn">Post announcement</button>
        </div>
      </form>
    `);
    document.getElementById('ann-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const title = document.getElementById('a-title').value.trim();
      const body = document.getElementById('a-body').value.trim();
      const category = document.getElementById('a-category').value;
      const pinned = document.getElementById('a-pinned').value === 'yes';
      const err = validate.required(title, 'Title') || validate.required(body, 'Message') || validate.maxLength(body, 2000, 'Message');
      if (err) { document.getElementById('ann-form-error').textContent = err; return; }
      DB.addAnnouncement({ id: makeId('ann'), title, body, category, pinned, datePosted: new Date().toISOString(), postedBy: session.name });
      closeModal();
      renderAnnouncements();
      renderOverview();
      toast('Announcement posted.');
    });
  }

  /* ================================================================
     STUDENTS
     ================================================================ */
  function renderStudents() {
    const students = DB.getStudents();
    const users = DB.getUsers();
    const tbody = document.querySelector('#students-table tbody');
    if (students.length === 0) {
      tbody.innerHTML = `<tr class="empty-row"><td colspan="4">No students yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = students.map(s => {
      const parent = users.find(u => u.role === 'parent' && (u.studentIds || []).includes(s.id));
      return `
      <tr>
        <td>${escapeHTML(s.name)}</td>
        <td>${escapeHTML(s.grade)}</td>
        <td>${parent ? escapeHTML(parentLabel(parent)) : '<span style="color:var(--slate)">Not linked</span>'}</td>
        <td class="row-actions"><button class="btn small danger" data-action="delete-student" data-id="${s.id}">Delete</button></td>
      </tr>`;
    }).join('');
  }

  function studentFormModal() {
    const parents = DB.getParentUsers();
    const parentOptions = parents.map(p => `<option value="${p.id}">${escapeHTML(parentLabel(p))}</option>`).join('');
    openModal(`
      <h2>Add student</h2>
      <form id="student-form">
        <div class="field-row">
          <div class="field"><label for="s-name">Student name</label><input type="text" id="s-name" maxlength="80" required></div>
          <div class="field"><label for="s-grade">Grade</label><input type="text" id="s-grade" maxlength="30" placeholder="e.g. Grade 6" required></div>
        </div>
        <div class="field">
          <label for="s-parent-mode">Parent/guardian account</label>
          <select id="s-parent-mode">
            <option value="existing">Link to an existing parent account</option>
            <option value="new">Create a new parent account</option>
          </select>
        </div>
        <div id="s-existing-wrap" class="field">
          <label for="s-parent-existing">Choose parent</label>
          <select id="s-parent-existing">${parentOptions || '<option value="">No parent accounts yet</option>'}</select>
        </div>
        <div id="s-new-wrap" style="display:none;">
          <div class="field"><label for="s-parent-name">Parent name</label><input type="text" id="s-parent-name" maxlength="80"></div>
          <div class="field-row">
            <div class="field"><label for="s-parent-username">Username</label><input type="text" id="s-parent-username" maxlength="40"></div>
            <div class="field"><label for="s-parent-password">Temporary password</label><input type="text" id="s-parent-password" maxlength="40"></div>
          </div>
        </div>
        <div class="field-error" id="student-form-error"></div>
        <div class="modal-actions">
          <button type="button" class="btn secondary" data-action="close-modal">Cancel</button>
          <button type="submit" class="btn">Add student</button>
        </div>
      </form>
    `);

    const modeSelect = document.getElementById('s-parent-mode');
    modeSelect.addEventListener('change', () => {
      const isNew = modeSelect.value === 'new';
      document.getElementById('s-existing-wrap').style.display = isNew ? 'none' : '';
      document.getElementById('s-new-wrap').style.display = isNew ? '' : 'none';
    });

    document.getElementById('student-form').addEventListener('submit', (e) => {
      e.preventDefault();
      const errorEl = document.getElementById('student-form-error');
      const name = document.getElementById('s-name').value.trim();
      const grade = document.getElementById('s-grade').value.trim();
      let err = validate.required(name, 'Student name') || validate.required(grade, 'Grade');
      if (err) { errorEl.textContent = err; return; }

      const studentId = makeId('stu');
      const mode = modeSelect.value;

      if (mode === 'existing') {
        const parentId = document.getElementById('s-parent-existing').value;
        if (!parentId) { errorEl.textContent = 'Choose a parent account, or create a new one.'; return; }
        DB.addStudent({ id: studentId, name, grade, parentUserId: parentId });
        DB.linkStudentToParent(parentId, studentId);
      } else {
        const pName = document.getElementById('s-parent-name').value.trim();
        const pUsername = document.getElementById('s-parent-username').value.trim();
        const pPassword = document.getElementById('s-parent-password').value;
        err = validate.required(pName, 'Parent name') || validate.required(pUsername, 'Username') || validate.required(pPassword, 'Temporary password');
        if (err) { errorEl.textContent = err; return; }
        if (pPassword.length < 8) { errorEl.textContent = 'Temporary password should be at least 8 characters.'; return; }
        if (DB.findUserByUsername(pUsername)) { errorEl.textContent = 'That username is already taken.'; return; }
        const parentId = makeId('user');
        DB.addParentUser({ id: parentId, role: 'parent', name: pName, username: pUsername, password: pPassword, studentIds: [studentId] });
        DB.addStudent({ id: studentId, name, grade, parentUserId: parentId });
      }

      closeModal();
      renderStudents();
      renderOverview();
      toast('Student added.');
    });
  }

  /* ================================================================
     Event delegation for dynamically-rendered action buttons
     ================================================================ */
  document.addEventListener('click', (e) => {
    const btn = e.target.closest('[data-action]');
    if (!btn) return;
    const action = btn.dataset.action;
    const id = btn.dataset.id;

    if (action === 'close-modal') { closeModal(); return; }

    if (action === 'pay') paymentFormModal(DB.getFees().find(f => f.id === id));
    if (action === 'edit-fee') feeFormModal(DB.getFees().find(f => f.id === id));
    if (action === 'delete-fee') {
      if (confirm('Delete this fee record? This cannot be undone.')) {
        DB.deleteFee(id); renderFees(); renderOverview(); toast('Fee record deleted.');
      }
    }
    if (action === 'delete-note') {
      if (confirm('Delete this note?')) { DB.deleteNote(id); renderNotes(); toast('Note deleted.'); }
    }
    if (action === 'toggle-pin') { DB.togglePin(id); renderAnnouncements(); renderOverview(); }
    if (action === 'delete-announcement') {
      if (confirm('Delete this announcement?')) { DB.deleteAnnouncement(id); renderAnnouncements(); renderOverview(); toast('Announcement deleted.'); }
    }
    if (action === 'delete-student') {
      if (confirm('Delete this student? Their fee records will also be removed.')) {
        DB.deleteStudent(id); renderStudents(); renderFees(); renderOverview(); toast('Student deleted.');
      }
    }
  });

  document.getElementById('add-fee-btn').addEventListener('click', () => feeFormModal(null));
  document.getElementById('add-note-btn').addEventListener('click', noteFormModal);
  document.getElementById('add-announcement-btn').addEventListener('click', announcementFormModal);
  document.getElementById('add-student-btn').addEventListener('click', studentFormModal);

  /* ---------------- Init ---------------- */
  function renderAll() {
    renderOverview();
    renderFees();
    renderNotes();
    renderAnnouncements();
    renderStudents();
  }
  renderAll();
})();
