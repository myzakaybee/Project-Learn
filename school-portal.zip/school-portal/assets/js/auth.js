/* =========================================================
   auth.js — demo authentication
   ---------------------------------------------------------
   This is intentionally simple and clearly labelled as a DEMO.
   A real deployment must replace this with server-side auth:
   hashed + salted passwords, sessions or signed tokens issued
   by a server, and access control enforced on the server for
   every request — never trust a role check that only runs in
   the browser. See README "Security & production notes".
   ========================================================= */

const Auth = (() => {
  const SESSION_KEY = 'sfsnu_v1_session';
  const ATTEMPTS_KEY = 'sfsnu_v1_login_attempts';
  const MAX_ATTEMPTS = 5;
  const LOCKOUT_MS = 30 * 1000;

  function getAttempts() {
    try { return JSON.parse(sessionStorage.getItem(ATTEMPTS_KEY)) || {}; }
    catch (e) { return {}; }
  }
  function saveAttempts(a) {
    sessionStorage.setItem(ATTEMPTS_KEY, JSON.stringify(a));
  }

  function isLockedOut(username) {
    const a = getAttempts()[username.toLowerCase()];
    if (!a) return 0;
    if (a.count >= MAX_ATTEMPTS && Date.now() - a.last < LOCKOUT_MS) {
      return LOCKOUT_MS - (Date.now() - a.last);
    }
    return 0;
  }

  function recordFailure(username) {
    const a = getAttempts();
    const key = username.toLowerCase();
    const prev = a[key] || { count: 0, last: 0 };
    a[key] = { count: prev.count + 1, last: Date.now() };
    saveAttempts(a);
  }

  function clearFailures(username) {
    const a = getAttempts();
    delete a[username.toLowerCase()];
    saveAttempts(a);
  }

  /**
   * Attempt a login. expectedRole restricts which tab the user
   * is allowed to sign in from ('admin' or 'parent').
   */
  function login(username, password, expectedRole) {
    username = String(username || '').trim();
    const lockMs = isLockedOut(username);
    if (lockMs > 0) {
      return { success: false, error: `Too many attempts. Try again in ${Math.ceil(lockMs / 1000)}s.` };
    }
    if (!username || !password) {
      return { success: false, error: 'Enter a username and password.' };
    }

    const user = DB.findUserByUsername(username);
    if (!user || user.password !== password || user.role !== expectedRole) {
      recordFailure(username);
      return { success: false, error: 'Incorrect username or password.' };
    }

    clearFailures(username);
    const session = { userId: user.id, role: user.role, name: user.name, ts: Date.now() };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(session));
    return { success: true, user };
  }

  function getSession() {
    try { return JSON.parse(sessionStorage.getItem(SESSION_KEY)); }
    catch (e) { return null; }
  }

  function logout() {
    sessionStorage.removeItem(SESSION_KEY);
    window.location.href = 'index.html';
  }

  /** Call at the top of a protected page. Redirects if not allowed. */
  function requireRole(role) {
    const session = getSession();
    if (!session || session.role !== role) {
      window.location.href = 'index.html';
      return null;
    }
    return session;
  }

  return { login, getSession, logout, requireRole };
})();
