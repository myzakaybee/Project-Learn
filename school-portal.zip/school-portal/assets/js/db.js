/* =========================================================
   db.js — client-side data layer
   ---------------------------------------------------------
   IMPORTANT (read the README's "Security & production notes"
   section): this stores data in the browser's localStorage.
   That is fine for a demo / portfolio build, but it means:
     - data lives only on the device that created it
     - anyone with access to that browser can read/edit it
     - there is no real authentication or access control
   All reads/writes go through the DB object below so this
   layer can be swapped for real `fetch()` calls to a backend
   API later without changing admin.js / portal.js much.
   ========================================================= */

const DB = (() => {
  const NS = 'sfsnu_v1_'; // namespace prefix, bump version if schema changes
  const KEYS = {
    users: NS + 'users',
    students: NS + 'students',
    fees: NS + 'fees',
    notes: NS + 'notes',
    announcements: NS + 'announcements',
    settings: NS + 'settings',
    seeded: NS + 'seeded'
  };

  function read(key, fallback) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : fallback;
    } catch (e) {
      console.error('DB read error for', key, e);
      return fallback;
    }
  }

  function write(key, value) {
    try {
      localStorage.setItem(key, JSON.stringify(value));
      return true;
    } catch (e) {
      console.error('DB write error for', key, e);
      toast('Could not save — your browser storage may be full or disabled.', 'error');
      return false;
    }
  }

  function seedIfEmpty() {
    if (read(KEYS.seeded, false)) return;

    const students = [
      { id: 'stu_1', name: 'Asha Naidoo', grade: 'Grade 8', parentUserId: 'user_parent1' },
      { id: 'stu_2', name: 'Liam Pretorius', grade: 'Grade 5', parentUserId: 'user_parent1' },
      { id: 'stu_3', name: 'Kgothatso Mokoena', grade: 'Grade 10', parentUserId: 'user_parent2' }
    ];

    const users = [
      // DEMO CREDENTIALS ONLY — see README "Security & production notes".
      // Plain-text demo passwords are NOT safe for a real deployment.
      { id: 'user_admin', role: 'admin', name: 'Mrs. Khumalo (Admin)', username: 'admin', password: 'Admin@123' },
      { id: 'user_parent1', role: 'parent', name: 'Mr. R. Naidoo', username: 'parent1', password: 'Parent@123', studentIds: ['stu_1', 'stu_2'] },
      { id: 'user_parent2', role: 'parent', name: 'Mrs. T. Mokoena', username: 'parent2', password: 'Parent@123', studentIds: ['stu_3'] }
    ];

    const today = new Date();
    const iso = (d) => d.toISOString().slice(0, 10);
    const addDays = (n) => { const d = new Date(today); d.setDate(d.getDate() + n); return iso(d); };

    const fees = [
      { id: 'fee_1', studentId: 'stu_1', term: 'Term 2', year: 2026, description: 'Tuition fees', amountDue: 4500, amountPaid: 4500, dueDate: addDays(-20), history: [{ date: addDays(-25), amount: 4500, method: 'EFT', note: 'Full payment' }] },
      { id: 'fee_2', studentId: 'stu_2', term: 'Term 2', year: 2026, description: 'Tuition fees', amountDue: 3800, amountPaid: 0, dueDate: addDays(-5), history: [] },
      { id: 'fee_3', studentId: 'stu_3', term: 'Term 2', year: 2026, description: 'Tuition + sports kit', amountDue: 5200, amountPaid: 2000, dueDate: addDays(10), history: [{ date: addDays(-10), amount: 2000, method: 'Card', note: 'Part payment' }] },
      { id: 'fee_4', studentId: 'stu_1', term: 'Term 3', year: 2026, description: 'Tuition fees', amountDue: 4500, amountPaid: 0, dueDate: addDays(35), history: [] }
    ];

    const notes = [
      { id: 'note_1', subject: 'Mathematics', grade: 'Grade 8', title: 'Algebra: factorising worksheet', content: 'Worksheet covering factorising quadratics. Complete questions 1–12 for homework.', postedBy: 'Mr. Dlamini', datePosted: addDays(-3) },
      { id: 'note_2', subject: 'English', grade: 'Grade 5', title: 'Comprehension — chapter 4 summary', content: 'Read chapter 4 of the class reader and write a half-page summary in your own words.', postedBy: 'Ms. van Wyk', datePosted: addDays(-1) },
      { id: 'note_3', subject: 'Life Sciences', grade: 'Grade 10', title: 'Cell structure revision notes', content: 'Revision notes for the upcoming test: organelles, their functions, and diagrams to label.', postedBy: 'Mrs. Adams', datePosted: addDays(-6) }
    ];

    const announcements = [
      { id: 'ann_1', title: 'Sports day moved to 14 August', body: 'Due to the weather forecast, sports day has been moved from 7 August to 14 August. All other arrangements stay the same.', category: 'event', pinned: true, datePosted: new Date(today.getTime() - 1000 * 60 * 60 * 5).toISOString(), postedBy: 'Admin office' },
      { id: 'ann_2', title: 'Term 3 fee statements now available', body: 'Term 3 fee statements have been issued. Please check the Fees section of the portal and contact the finance office with any queries.', category: 'general', pinned: false, datePosted: new Date(today.getTime() - 1000 * 60 * 60 * 30).toISOString(), postedBy: 'Finance office' },
      { id: 'ann_3', title: 'Early closure — staff training day', body: 'The school will close at 12:00 on Friday for a staff training day. Aftercare will not be available that day.', category: 'urgent', pinned: true, datePosted: new Date(today.getTime() - 1000 * 60 * 60 * 50).toISOString(), postedBy: 'Admin office' }
    ];

    write(KEYS.students, students);
    write(KEYS.users, users);
    write(KEYS.fees, fees);
    write(KEYS.notes, notes);
    write(KEYS.announcements, announcements);
    write(KEYS.settings, { schoolName: 'Thornfield Academy' });
    write(KEYS.seeded, true);
  }

  seedIfEmpty();

  return {
    // settings
    getSettings: () => read(KEYS.settings, { schoolName: 'School Portal' }),
    saveSettings: (s) => write(KEYS.settings, s),

    // users / auth support
    getUsers: () => read(KEYS.users, []),
    findUserByUsername: (username) => read(KEYS.users, []).find(u => u.username.toLowerCase() === String(username || '').toLowerCase()),

    // students
    getStudents: () => read(KEYS.students, []),
    getStudent: (id) => read(KEYS.students, []).find(s => s.id === id),
    getStudentsForParent: (userId) => {
      const user = read(KEYS.users, []).find(u => u.id === userId);
      const ids = (user && user.studentIds) || [];
      return read(KEYS.students, []).filter(s => ids.includes(s.id));
    },
    addStudent: (student) => {
      const students = read(KEYS.students, []);
      students.push(student);
      write(KEYS.students, students);
    },
    deleteStudent: (id) => {
      write(KEYS.students, read(KEYS.students, []).filter(s => s.id !== id));
      write(KEYS.fees, read(KEYS.fees, []).filter(f => f.studentId !== id));
      const users = read(KEYS.users, []).map(u => {
        if (u.studentIds && u.studentIds.includes(id)) {
          return { ...u, studentIds: u.studentIds.filter(sid => sid !== id) };
        }
        return u;
      });
      write(KEYS.users, users);
    },

    // parent users (admin can link a student to an existing parent, or create one)
    getParentUsers: () => read(KEYS.users, []).filter(u => u.role === 'parent'),
    addParentUser: (user) => {
      const users = read(KEYS.users, []);
      users.push(user);
      write(KEYS.users, users);
    },
    linkStudentToParent: (parentUserId, studentId) => {
      const users = read(KEYS.users, []);
      const idx = users.findIndex(u => u.id === parentUserId);
      if (idx === -1) return false;
      users[idx].studentIds = users[idx].studentIds || [];
      if (!users[idx].studentIds.includes(studentId)) users[idx].studentIds.push(studentId);
      write(KEYS.users, users);
      return true;
    },

    // fees
    getFees: () => read(KEYS.fees, []),
    getFeesForStudents: (studentIds) => read(KEYS.fees, []).filter(f => studentIds.includes(f.studentId)),
    addFee: (fee) => {
      const fees = read(KEYS.fees, []);
      fees.unshift(fee);
      write(KEYS.fees, fees);
    },
    updateFee: (id, patch) => {
      const fees = read(KEYS.fees, []);
      const idx = fees.findIndex(f => f.id === id);
      if (idx === -1) return false;
      fees[idx] = { ...fees[idx], ...patch };
      write(KEYS.fees, fees);
      return true;
    },
    deleteFee: (id) => {
      write(KEYS.fees, read(KEYS.fees, []).filter(f => f.id !== id));
    },
    recordPayment: (id, amount, method, note) => {
      const fees = read(KEYS.fees, []);
      const idx = fees.findIndex(f => f.id === id);
      if (idx === -1) return false;
      const f = fees[idx];
      f.amountPaid = Math.min((Number(f.amountPaid) || 0) + Number(amount), 999999999);
      f.history = f.history || [];
      f.history.unshift({ date: todayISO(), amount: Number(amount), method, note });
      write(KEYS.fees, fees);
      return true;
    },

    // notes
    getNotes: () => read(KEYS.notes, []).sort((a, b) => (b.datePosted || '').localeCompare(a.datePosted || '')),
    addNote: (note) => {
      const notes = read(KEYS.notes, []);
      notes.unshift(note);
      write(KEYS.notes, notes);
    },
    deleteNote: (id) => {
      write(KEYS.notes, read(KEYS.notes, []).filter(n => n.id !== id));
    },

    // announcements
    getAnnouncements: () => read(KEYS.announcements, []).sort((a, b) => {
      if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
      return (b.datePosted || '').localeCompare(a.datePosted || '');
    }),
    addAnnouncement: (a) => {
      const list = read(KEYS.announcements, []);
      list.unshift(a);
      write(KEYS.announcements, list);
    },
    deleteAnnouncement: (id) => {
      write(KEYS.announcements, read(KEYS.announcements, []).filter(a => a.id !== id));
    },
    togglePin: (id) => {
      const list = read(KEYS.announcements, []);
      const idx = list.findIndex(a => a.id === id);
      if (idx === -1) return false;
      list[idx].pinned = !list[idx].pinned;
      write(KEYS.announcements, list);
      return true;
    },

    // dangerous — exposed only for the "reset demo data" button
    resetAll: () => {
      Object.values(KEYS).forEach(k => localStorage.removeItem(k));
      seedIfEmpty();
    }
  };
})();
