/* =========================================================
   portal.js — parent/student portal behaviour
   ========================================================= */

(function () {
  const session = Auth.requireRole('parent');
  if (!session) return;

  document.getElementById('parent-name').textContent = session.name;

  const allChildren = DB.getStudentsForParent(session.userId);
  let scopeStudentId = 'all'; // 'all' or a specific student id

  /* ---------------- Child switcher ---------------- */
  if (allChildren.length > 1) {
    const wrap = document.getElementById('child-switcher-wrap');
    wrap.style.display = '';
    const select = document.getElementById('child-switcher');
    select.innerHTML = `<option value="all">All my children</option>` +
      allChildren.map(c => `<option value="${c.id}">${escapeHTML(c.name)} — ${escapeHTML(c.grade)}</option>`).join('');
    select.addEventListener('change', () => {
      scopeStudentId = select.value;
      renderAll();
    });
  }

  function studentsInScope() {
    if (scopeStudentId === 'all') return allChildren;
    return allChildren.filter(c => c.id === scopeStudentId);
  }

  /* ---------------- Navigation ---------------- */
  const titles = {
    overview: ['Overview', 'A quick look at fees, notes and announcements'],
    fees: ['My fees', 'Statements and payment history'],
    notes: ['Class notes & resources', 'Shared by your child\u2019s teachers'],
    announcements: ['Announcements & updates', 'School-wide notices']
  };
  document.querySelectorAll('.nav-item').forEach(item => {
    item.addEventListener('click', () => {
      const target = item.dataset.section;
      document.querySelectorAll('.nav-item').forEach(n => { n.classList.remove('active'); n.removeAttribute('aria-current'); });
      item.classList.add('active');
      item.setAttribute('aria-current', 'page');
      document.querySelectorAll('.section').forEach(s => s.classList.remove('active'));
      document.getElementById('section-' + target).classList.add('active');
      document.getElementById('page-title').textContent = titles[target][0];
      document.getElementById('page-sub').textContent = titles[target][1];
      document.getElementById('sidebar').classList.remove('open');
    });
  });
  document.getElementById('menu-btn').addEventListener('click', () => {
    document.getElementById('sidebar').classList.toggle('open');
  });
  document.getElementById('logout-btn').addEventListener('click', Auth.logout);

  /* ---------------- Shared render helpers ---------------- */
  function studentName(id) {
    const s = allChildren.find(c => c.id === id);
    return s ? s.name : 'Student';
  }

  function renderAnnouncementEntry(a) {
    const tagClass = a.category === 'urgent' ? 'urgent' : a.category === 'event' ? 'event' : '';
    return `
      <div class="entry ${a.pinned ? 'pinned' : ''}">
        <div class="entry-top">
          <div>
            <h3>${escapeHTML(a.title)}</h3>
            <div class="meta">
              <span class="tag ${tagClass}">${escapeHTML(a.category)}</span>
              ${a.pinned ? '<span class="tag pinned">Pinned</span>' : ''}
              · ${escapeHTML(a.postedBy)} · ${formatDateTime(a.datePosted)}
            </div>
          </div>
        </div>
        <div class="body-text">${escapeHTML(a.body)}</div>
      </div>`;
  }

  function renderNoteEntry(n) {
    return `
      <div class="entry">
        <div class="entry-top">
          <div>
            <h3>${escapeHTML(n.title)}</h3>
            <div class="meta">${escapeHTML(n.subject)} · ${escapeHTML(n.grade)} · posted by ${escapeHTML(n.postedBy)} · ${formatDate(n.datePosted)}</div>
          </div>
        </div>
        <div class="body-text">${escapeHTML(n.content)}</div>
      </div>`;
  }

  /* ---------------- Overview ---------------- */
  function renderOverview() {
    const ids = studentsInScope().map(s => s.id);
    const fees = DB.getFeesForStudents(ids);
    const outstanding = fees.reduce((sum, f) => sum + Math.max(0, Number(f.amountDue) - Number(f.amountPaid)), 0);
    const overdueCount = fees.filter(f => feeStatus(f) === 'overdue').length;
    const upcoming = fees.filter(f => feeStatus(f) !== 'paid').sort((a, b) => (a.dueDate || '').localeCompare(b.dueDate || ''))[0];

    document.getElementById('stat-grid').innerHTML = `
      <div class="stat-tile ${outstanding > 0 ? 'alert' : ''}"><div class="num mono">${formatCurrency(outstanding)}</div><div class="label">Outstanding</div></div>
      <div class="stat-tile ${overdueCount ? 'alert' : ''}"><div class="num">${overdueCount}</div><div class="label">Overdue statements</div></div>
      <div class="stat-tile"><div class="num">${upcoming ? formatDate(upcoming.dueDate) : '—'}</div><div class="label">Next due date</div></div>
    `;

    document.getElementById('overview-announcements').innerHTML =
      DB.getAnnouncements().slice(0, 3).map(renderAnnouncementEntry).join('') || `<p style="color:var(--slate); font-size:13.5px;">No announcements yet.</p>`;

    const grades = [...new Set(studentsInScope().map(s => s.grade))];
    const notes = DB.getNotes().filter(n => grades.includes(n.grade)).slice(0, 3);
    document.getElementById('overview-notes').innerHTML =
      notes.map(renderNoteEntry).join('') || `<p style="color:var(--slate); font-size:13.5px;">No notes for this grade yet.</p>`;
  }

  /* ---------------- Fees ---------------- */
  function renderFees() {
    const ids = studentsInScope().map(s => s.id);
    const fees = DB.getFeesForStudents(ids);
    const tbody = document.querySelector('#fees-table tbody');
    if (fees.length === 0) {
      tbody.innerHTML = `<tr class="empty-row"><td colspan="7">No fee statements yet.</td></tr>`;
      return;
    }
    tbody.innerHTML = fees.map(f => {
      const status = feeStatus(f);
      const history = (f.history || []).map(h =>
        `<div style="font-size:12.5px; color:var(--slate); padding:3px 0;">${formatDate(h.date)} · ${escapeHTML(h.method)} · <span class="mono">${formatCurrency(h.amount)}</span>${h.note ? ' · ' + escapeHTML(h.note) : ''}</div>`
      ).join('') || `<div style="font-size:12.5px; color:var(--slate);">No payments recorded yet.</div>`;
      return `
      <tr class="fee-row" data-toggle="${f.id}" tabindex="0" role="button" aria-expanded="false" aria-controls="history-${f.id}" style="cursor:pointer;">
        <td>${escapeHTML(studentName(f.studentId))}</td>
        <td>${escapeHTML(f.term)} ${escapeHTML(String(f.year))}</td>
        <td>${escapeHTML(f.description)}</td>
        <td class="amount">${formatCurrency(f.amountDue)}</td>
        <td class="amount">${formatCurrency(f.amountPaid)}</td>
        <td>${formatDate(f.dueDate)}</td>
        <td><span class="stamp ${status}">${STATUS_LABEL[status]}</span></td>
      </tr>
      <tr class="fee-history-row" id="history-${f.id}" style="display:none;">
        <td colspan="7" style="background:var(--paper); padding:10px 16px;">${history}</td>
      </tr>`;
    }).join('');

    tbody.querySelectorAll('[data-toggle]').forEach(row => {
      const toggle = () => {
        const hist = document.getElementById('history-' + row.dataset.toggle);
        const isOpen = hist.style.display !== 'none';
        hist.style.display = isOpen ? 'none' : '';
        row.setAttribute('aria-expanded', String(!isOpen));
      };
      row.addEventListener('click', toggle);
      row.addEventListener('keydown', (e) => {
        if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); toggle(); }
      });
    });
  }

  /* ---------------- Notes ---------------- */
  function renderNotes() {
    const grades = [...new Set(studentsInScope().map(s => s.grade))];
    const notes = DB.getNotes().filter(n => grades.includes(n.grade));
    document.getElementById('notes-list').innerHTML = notes.length
      ? notes.map(renderNoteEntry).join('')
      : `<p style="color:var(--slate); font-size:13.5px;">No notes for this grade yet.</p>`;
  }

  /* ---------------- Announcements ---------------- */
  function renderAnnouncements() {
    document.getElementById('announcements-list').innerHTML = DB.getAnnouncements().map(renderAnnouncementEntry).join('');
  }

  function renderAll() {
    renderOverview();
    renderFees();
    renderNotes();
    renderAnnouncements();
  }
  renderAll();
})();
