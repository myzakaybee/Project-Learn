/* =========================================================
   utils.js — shared helpers used by both admin.js and portal.js
   No external dependencies. Keep this file dependency-free so
   it can be reused if the project later moves to a real backend.
   ========================================================= */

/**
 * Escape a string for safe insertion into innerHTML.
 * Every piece of user-supplied text in this app (names, note
 * titles, announcement bodies, etc.) MUST pass through this
 * before being placed in the DOM via innerHTML/template strings,
 * to prevent stored XSS.
 */
function escapeHTML(str) {
  if (str === null || str === undefined) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

/** Format a number as South African Rand currency, e.g. R 4 500.00 */
function formatCurrency(amount) {
  const n = Number(amount) || 0;
  return 'R ' + n.toLocaleString('en-ZA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

/** Format an ISO date string (YYYY-MM-DD) into "12 Aug 2026" */
function formatDate(isoString) {
  if (!isoString) return '—';
  const d = new Date(isoString + 'T00:00:00');
  if (isNaN(d.getTime())) return isoString;
  return d.toLocaleDateString('en-ZA', { day: 'numeric', month: 'short', year: 'numeric' });
}

/** Format an ISO datetime into a relative-ish short date for feeds */
function formatDateTime(isoString) {
  if (!isoString) return '—';
  const d = new Date(isoString);
  if (isNaN(d.getTime())) return isoString;
  return d.toLocaleDateString('en-ZA', { day: 'numeric', month: 'short', year: 'numeric' }) +
    ' · ' + d.toLocaleTimeString('en-ZA', { hour: '2-digit', minute: '2-digit' });
}

function todayISO() {
  return new Date().toISOString().slice(0, 10);
}

/**
 * Compute a fee record's status from amounts and due date.
 * Returns one of: 'paid' | 'partial' | 'due' | 'overdue'
 */
function feeStatus(record) {
  const due = Number(record.amountDue) || 0;
  const paid = Number(record.amountPaid) || 0;
  if (paid >= due && due > 0) return 'paid';
  const isPast = record.dueDate && record.dueDate < todayISO();
  if (paid > 0 && paid < due) return isPast ? 'overdue' : 'partial';
  if (isPast) return 'overdue';
  return 'due';
}

const STATUS_LABEL = { paid: 'Paid', partial: 'Partial', due: 'Due', overdue: 'Overdue' };

/** Basic input validators — return an error string, or '' if valid */
const validate = {
  required(value, label) {
    return String(value || '').trim() === '' ? `${label} is required.` : '';
  },
  positiveNumber(value, label) {
    const n = Number(value);
    if (value === '' || value === null || value === undefined) return `${label} is required.`;
    if (isNaN(n) || n < 0) return `${label} must be a positive number.`;
    return '';
  },
  maxLength(value, max, label) {
    return String(value || '').length > max ? `${label} must be ${max} characters or fewer.` : '';
  }
};

/** Lightweight id generator — fine for a client-side demo data store */
function makeId(prefix) {
  return `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 8)}`;
}

/** Toast notifications */
function toast(message, type) {
  let host = document.getElementById('toast-host');
  if (!host) {
    host = document.createElement('div');
    host.id = 'toast-host';
    document.body.appendChild(host);
  }
  const el = document.createElement('div');
  el.className = 'toast' + (type === 'error' ? ' error' : '');
  el.textContent = message; // textContent, not innerHTML — safe by construction
  host.appendChild(el);
  setTimeout(() => el.remove(), 3200);
}

/** Debounce helper for search inputs */
function debounce(fn, wait) {
  let t;
  return (...args) => {
    clearTimeout(t);
    t = setTimeout(() => fn(...args), wait);
  };
}
